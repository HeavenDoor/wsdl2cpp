
Web services support for the Palm OS Platform is no longer available for gSOAP
versions 2.7.9 and up.

Please download gSOAP 2.7.8c for the most up-to-date release with Palm OS
support.

Thank you.

- Robert
